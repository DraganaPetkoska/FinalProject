package mk.edu.seeu.java.spring.controllers;

import mk.edu.seeu.java.spring.models.Advertisement;
import mk.edu.seeu.java.spring.models.Category;
import mk.edu.seeu.java.spring.repositories.ADREPO;
import mk.edu.seeu.java.spring.repositories.CategoryRepo;
import net.bytebuddy.implementation.bind.MethodDelegationBinder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

@Controller
public class SimpleController {
    @Value("${spring.application.name}")
    String appName;

    @Autowired
    private ADREPO adrepo;

    @Autowired
    private CategoryRepo catRepo;

    @GetMapping("/")
    public String homePage(Model model) {
        model.addAttribute("appName", appName);


        Iterable<Advertisement> ads = adrepo.findAll();
        Iterable<Category> cats = catRepo.findAll();


        model.addAttribute("ads", ads);
        model.addAttribute("cats",cats);
        return "home";
    }

    @GetMapping("/learn-more")
    public String showLearnMore(Model model) {
        model.addAttribute("appName", appName);

        Iterable<Advertisement> ads = adrepo.findAll();
        Iterable<Category> cats = catRepo.findAll();


        model.addAttribute("ads", ads);
        model.addAttribute("cats",cats);

        return "learn-more";
    }

    @GetMapping("/contact")
    public String showContact(Model model) {
        model.addAttribute("appName", appName);

        Iterable<Advertisement> ads = adrepo.findAll();
        Iterable<Category> cats = catRepo.findAll();


        model.addAttribute("ads", ads);
        model.addAttribute("cats",cats);

        return "contact-us";
    }

    @GetMapping("/addAdvertisement")
    public String showForm(Model model) {
        Advertisement user = new Advertisement();
        model.addAttribute("user", user);

        Iterable<Category> cats = catRepo.findAll();

        model.addAttribute("cats",cats);
        model.addAttribute("appName", appName);


        return "addAdvertisement";
    }

    @PostMapping("/successADV")
    public String submitForm(@ModelAttribute("user") Advertisement user) {

        Advertisement newAd = new Advertisement(user.getTitle(), user.getAuthor(), user.getContent(), ""+user.getPrice(), user.getPhone() , user.getImage(),user.getCat());

        adrepo.save(newAd);
        return "ADSucess";
    }

    @GetMapping("/advertisements/{id}")
    public String showAdvertisement(Model model, @PathVariable Long id) {
        Advertisement ad = adrepo.findById(id).orElse(new Advertisement());
        model.addAttribute("advertisement", ad);
        return "advertisement";
    }

    @GetMapping("/categories")
    public String showCategoeis(Model model) {
        model.addAttribute("appName", appName);

        Iterable<Category> cats = catRepo.findAll();

        model.addAttribute("cats",cats);
        return "categories";
    }

    @GetMapping("/category/{id}")
    public String showCategory(Model model, @PathVariable Long id) {
        Advertisement ad = adrepo.findById(id).orElse(new Advertisement());

        Iterable<Advertisement> ads = adrepo.findAll();

        Iterable<Category> cats = catRepo.findAll();

        model.addAttribute("cats",cats);

        Iterator<Advertisement> adITR = ads.iterator();
        List<Advertisement> listaa = new LinkedList<Advertisement>();

        while(adITR.hasNext()){

            Advertisement addd = adITR.next();

            if(addd.getCat()==id){
            listaa.add(addd);
            }

        }

        Iterable<Advertisement> finalADS = listaa;


        model.addAttribute("advertisements", finalADS);
        return "category";
    }

}