package mk.edu.seeu.java.spring;

import mk.edu.seeu.java.spring.models.Advertisement;
import mk.edu.seeu.java.spring.models.Category;
import mk.edu.seeu.java.spring.repositories.ADREPO;
import mk.edu.seeu.java.spring.repositories.CategoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.Arrays;
import java.util.List;

@EnableJpaRepositories("mk.edu.seeu.java.spring.repositories")
@EntityScan("mk.edu.seeu.java.spring.models")

@SpringBootApplication
public class
SpringProjectApplication {

	@Autowired
	CategoryRepo catrepo;


	public static void main(String[] args) {
		SpringApplication.run(SpringProjectApplication.class, args);


	
	}




}
