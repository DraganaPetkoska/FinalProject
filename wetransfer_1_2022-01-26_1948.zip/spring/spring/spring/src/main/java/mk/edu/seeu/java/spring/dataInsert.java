package mk.edu.seeu.java.spring;

import mk.edu.seeu.java.spring.models.Advertisement;
import mk.edu.seeu.java.spring.models.Category;
import mk.edu.seeu.java.spring.repositories.ADREPO;
import mk.edu.seeu.java.spring.repositories.CategoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class dataInsert implements ApplicationListener<ContextRefreshedEvent>  {

    @Autowired
    private CategoryRepo catRepo;

    @Autowired
    private ADREPO adrepo;


    public void onApplicationEvent(ContextRefreshedEvent event) {
        catRepo.save(new Category("Houses"));
        catRepo.save(new Category("Apartments"));
        catRepo.save(new Category("Cars"));
        catRepo.save(new Category("Boats"));
        catRepo.save(new Category("Other"));


















        adrepo.save(new Advertisement("BMW 116 DIZEL UVOS OD SVAJCARIJA 2010 GODINA\n","Zoran","BMW 116 DIZEL 85 KW 116 KS SO MANUEL 6 BRZINI ODLICNA SOSTOJBA UVOS OD SVAJCARSKA FUL OPREMA 2010 GODINA VO IDEALNA PERFEKTNA SOSTOJBA. SO FUL GOLEM SERVIS NAPRAVENO.. BES ZABELESKA","150000","07505757","https://media.pazar3.mk/Image/6c8084e2-fd8c-4761-a307-bd0eb09c1f7a/20201018/false/false/1280/960/BMW-116-DIZEL-UVOS-OD-SVAJCARIJA-2010-GODINA-.jpeg?noLogo=true",3));

        adrepo.save(new Advertisement("Vila Dajana\n","Zvonko","se prodava vila dajan a se prodava vila dajanase prodava vila dajanase prodava vila dajanase prodava vila dajana" , "152000000","232323145","https://media.pazar3.mk/Image/e00a649d9cdf4845b74be8d15dece0cf/20200228/false/false/1280/960/Vila-Dajana.jpeg?noLogo=true",1));

        adrepo.save(new Advertisement("Se prodava gliser","Osman","se prodava nov gliser se prodava nov gliserse prodava nov gliserse prodava nov gliserse prodava nov gliserse prodava nov gliserse prodava nov gliserse prodava nov gliserse prodava nov gliserse prodava nov gliser", "3000000", "654438435","",4));


    }


}

