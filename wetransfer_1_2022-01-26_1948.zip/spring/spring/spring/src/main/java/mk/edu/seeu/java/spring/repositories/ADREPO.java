package mk.edu.seeu.java.spring.repositories;

import mk.edu.seeu.java.spring.models.Advertisement;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ADREPO extends CrudRepository<Advertisement, Long> {

    List<Advertisement> findByTitle(String title);

}
