package mk.edu.seeu.java.spring.models;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.util.List;

@Entity
public class Category {

    @javax.persistence.Id
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long cat_id;

    @Column(nullable = false, unique = true)
    private String title;

    @OneToMany(mappedBy = "cat")
    private List<Advertisement> ads;

    public Category(String title) {
        this.title = title;
    }

    public Category() {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getId() {
        return cat_id;
    }
}
