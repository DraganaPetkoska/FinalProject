package mk.edu.seeu.java.spring.models;

import org.springframework.data.annotation.Id;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Advertisement {

    @javax.persistence.Id
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(nullable = false, unique = true)
    private String title;

    @Column(nullable = false)
    private String author;

    @Column(nullable = false)
    private String content;

    @Column(nullable = false)
    private String date;

    @Column(nullable = false)
    private int price;

    @Column(nullable = false)
    private String phone;

    @Column(nullable = false)
    private String image;


    private int  cat;



    public Advertisement() {

    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Advertisement(final String title, final String author) {
        this.title = title;
        this.author = author;
        this.content = "";
        this.date = "" + new Date();
        this.price = 0;
        this.phone = "No phone available";
        this.image = "https://st4.depositphotos.com/17828278/24401/v/600/depositphotos_244011872-stock-illustration-image-vector-symbol-missing-available.jpg";
    }

    public Advertisement(final String title, final String author, String content, String price, String phone , String image, int cat_id) {
        this.title = title;
        this.author = author;
        this.content = content;
        this.date = "" + new Date();
        this.price = Integer.parseInt(price);

        if(phone.length()>0)
            this.phone = phone;
        else
            this.phone = "No phone available";

        if(image.length()>0)
            this.image = image;
        else
            this.image = "https://st4.depositphotos.com/17828278/24401/v/600/depositphotos_244011872-stock-illustration-image-vector-symbol-missing-available.jpg";

        cat = cat_id;

    }

    public int getCat() {
        return cat;
    }

    public void setCat(int cat) {
        this.cat = cat;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
