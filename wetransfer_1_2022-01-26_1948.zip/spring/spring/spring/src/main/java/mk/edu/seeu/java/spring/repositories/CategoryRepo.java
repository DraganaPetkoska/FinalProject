
package mk.edu.seeu.java.spring.repositories;

import mk.edu.seeu.java.spring.models.Category;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CategoryRepo extends CrudRepository<Category, Long> {

    List<Category> findByTitle(String title);

}
